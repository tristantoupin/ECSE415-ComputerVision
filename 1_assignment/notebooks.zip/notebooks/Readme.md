Readme.md

Python module used:
matplotlib==2.1.0
opencv-python==3.4.3.18
numpy==1.13.3
